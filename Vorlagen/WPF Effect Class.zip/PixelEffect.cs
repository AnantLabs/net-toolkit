﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Effects;
using System.Windows;
using System.Windows.Media;

namespace $rootnamespace$
{
    public class $safeitemname$ : ShaderEffect
    {
        #region Static Members
        private readonly static PixelShader shader =
            new PixelShader()
            {
				//TODO: Set shader
                UriSource = new Uri(@"pack://application:,,, /$rootnamespace$;component/MyShader.ps")
            };

        public static readonly DependencyProperty InputProperty =
            ShaderEffect.RegisterPixelShaderSamplerProperty(
                    "Input",
                    typeof($safeitemname$),
                    0);

        #endregion

        public $safeitemname$()
        {
			PixelShader = shader;
			
			UpdateShaderValue(InputProperty);
        }

        public Brush Input
        {
            get { return (Brush)GetValue(InputProperty); }
            set { SetValue(InputProperty, value); }
        }
    }
}
